export const workspaceTemplate = String.raw`#!/usr/bin/env python3
"""AI Exchange metadata workspace. Run on a participant's own authorized server.
Set WORKSPACE_TOKEN_A, WORKSPACE_TOKEN_B (distinct, >=32 chars), PUBLIC_ORIGIN (HTTPS).
Put behind an HTTPS reverse proxy. Bind is loopback by default. No file uploads.
Arrange host-side deletion on schedule; expiry is also checked on every request.
"""
import os, json, time, hmac, sqlite3, threading
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

TOKENS = {k: os.environ['WORKSPACE_TOKEN_' + k] for k in ('A', 'B')}
if any(len(v) < 32 for v in TOKENS.values()) or TOKENS['A'] == TOKENS['B']:
    raise SystemExit('Use distinct high-entropy tokens of at least 32 characters.')
ORIGIN = os.environ['PUBLIC_ORIGIN'].rstrip('/')
if not ORIGIN.startswith('https://'):
    raise SystemExit('PUBLIC_ORIGIN must be HTTPS; terminate TLS at your proxy.')
DB = os.environ.get('WORKSPACE_DB', 'workspace.sqlite3')
TTL = min(168, max(1, int(os.environ.get('WORKSPACE_TTL_HOURS', '24'))))
TASK = os.environ.get('WORKSPACE_ID', 'shared-task')
with sqlite3.connect(DB) as c:
    c.execute('CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
    c.execute('INSERT OR IGNORE INTO config VALUES (?,?)', ('expires_at', str(int(time.time()) + TTL*3600)))
    c.execute('CREATE TABLE IF NOT EXISTS messages (seq INTEGER PRIMARY KEY AUTOINCREMENT, message_id TEXT UNIQUE, author TEXT, payload TEXT, created_at INTEGER)')
RATE, LOCK = {}, threading.Lock()

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Do not log tokens or private message payloads.
    def reply(self, status, value):
        raw = json.dumps(value).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
    def authenticated(self):
        token = self.headers.get('Authorization', '').removeprefix('Bearer ')
        role = next((k for k, v in TOKENS.items() if hmac.compare_digest(token, v)), None)
        if not role:
            self.reply(401, {'error': 'valid scoped bearer token required'})
            return None
        with sqlite3.connect(DB) as c:
            expiry = int(c.execute('SELECT value FROM config WHERE key=?', ('expires_at',)).fetchone()[0])
            if time.time() >= expiry:
                c.execute('DELETE FROM messages')
                self.reply(410, {'error': 'workspace expired; message rows deleted'})
                return None
        return role, expiry
    def do_GET(self):
        auth = self.authenticated()
        if not auth: return
        role, expiry = auth
        p = urlparse(self.path)
        if p.path == '/workspace':
            return self.reply(200, {'protocol':'ai-exchange-workspace/1','task_id':TASK,'host':ORIGIN,'expires_at_unix':expiry,'participants':['A','B'],'caller':role,'capabilities':['metadata_messages'],'limits':{'body_bytes':4096,'messages':1000,'write_per_minute_per_role':20},'credentials':'separate bearer tokens, exchanged out of band','file_uploads':False})
        if p.path == '/messages':
            try: after = max(0, int(parse_qs(p.query).get('after',['0'])[0]))
            except ValueError: return self.reply(400, {'error':'after must be a sequence number'})
            with sqlite3.connect(DB) as c:
                rows = c.execute('SELECT seq,message_id,author,payload,created_at FROM messages WHERE seq>? ORDER BY seq LIMIT 50', (after,)).fetchall()
            return self.reply(200, {'items':[{'seq':r[0],'message_id':r[1],'author':r[2],'payload':json.loads(r[3]),'created_at_unix':r[4]} for r in rows],'next_cursor':rows[-1][0] if rows else after})
        self.reply(404, {'error':'not found'})
    def do_POST(self):
        auth = self.authenticated()
        if not auth: return
        role, _ = auth
        if urlparse(self.path).path != '/messages': return self.reply(404, {'error':'not found'})
        if not self.headers.get('Content-Type','').startswith('application/json'): return self.reply(415, {'error':'JSON only'})
        try: length = int(self.headers.get('Content-Length','0'))
        except ValueError: return self.reply(400, {'error':'invalid length'})
        if not 0 < length <= 4096: return self.reply(413, {'error':'maximum 4096 bytes'})
        try:
            b = json.loads(self.rfile.read(length))
            assert isinstance(b,dict) and set(b) <= {'message_id','in_reply_to','type','summary','links'}
            assert isinstance(b.get('message_id'),str) and 1 <= len(b['message_id']) <= 100
            assert b.get('type') in ('request','response','progress','result','error')
            assert isinstance(b.get('summary'),str) and len(b['summary']) <= 1000
            assert isinstance(b.get('links',[]),list) and len(b.get('links',[])) <= 8
            assert all(isinstance(x,str) and len(x)<=2048 and x.startswith('https://') for x in b.get('links',[]))
        except (ValueError, AssertionError, TypeError): return self.reply(400, {'error':'invalid metadata; no embedded files'})
        bucket = int(time.time()//60)
        with LOCK:
            old_bucket, count = RATE.get(role, (bucket,0))
            count = count if old_bucket == bucket else 0
            if count >= 20: return self.reply(429, {'error':'retry after one minute'})
            RATE[role] = (bucket,count+1)
        payload = json.dumps(b,sort_keys=True)
        with sqlite3.connect(DB) as c:
            existing = c.execute('SELECT seq,author,payload FROM messages WHERE message_id=?',(b['message_id'],)).fetchone()
            if existing:
                if existing[1] != role or existing[2] != payload: return self.reply(409, {'error':'message_id already used with different content'})
                return self.reply(200, {'seq':existing[0],'duplicate':True})
            if c.execute('SELECT COUNT(*) FROM messages').fetchone()[0] >= 1000: return self.reply(429, {'error':'workspace capacity reached'})
            cur = c.execute('INSERT INTO messages(message_id,author,payload,created_at) VALUES(?,?,?,?)',(b['message_id'],role,payload,int(time.time())))
            return self.reply(201, {'seq':cur.lastrowid,'duplicate':False})

ThreadingHTTPServer((os.environ.get('BIND','127.0.0.1'),int(os.environ.get('PORT','8787'))),Handler).serve_forever()
`;
