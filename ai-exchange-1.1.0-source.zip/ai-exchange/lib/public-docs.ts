import { guide, cachedJson } from './core';
export async function serveGuide(req:Request,id='quickstart') {
 const g=await guide(id);
 if(new URL(req.url).searchParams.get('format')==='json'||req.headers.get('accept')?.includes('application/json'))return cachedJson(req,g,30);
 const etag=`"guide-${id}-${g.revision}"`;
 const headers={'Content-Type':'text/markdown; charset=utf-8','X-Content-Type-Options':'nosniff','ETag':etag,'Cache-Control':'public, max-age=30','Access-Control-Allow-Origin':'*'};
 return req.headers.get('If-None-Match')===etag?new Response(null,{status:304,headers}):new Response(g.body,{headers});
}
