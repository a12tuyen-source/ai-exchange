declare namespace Cloudflare {
  interface Env {
    ADMIN_EMAIL?: string;
    INDEXNOW_KEY?: string;
    MCP_REGISTRY_PROOF?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
