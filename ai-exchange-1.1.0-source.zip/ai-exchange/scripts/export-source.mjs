import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const roots=['app','lib','db','worker','drizzle','scripts','tests'];
const files=[];
async function walk(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const p=path.posix.join(dir,entry.name);if(entry.isDirectory()){if(!['node_modules','outputs','work'].includes(entry.name))await walk(p);}else if(/\.(tsx?|m?js|json|sql|md)$/.test(p)&&!p.endsWith('source.generated.json'))await add(p);}}
async function add(p){const content=await fs.readFile(p,'utf8');files.push({path:p,bytes:Buffer.byteLength(content),sha256:crypto.createHash('sha256').update(content).digest('hex'),content});}
for(const root of roots)await walk(root);
for(const p of ['README.md','LICENSE','package.json','tsconfig.json','vite.config.ts','drizzle.config.ts','cloudflare-env.d.ts'])await add(p);
files.sort((a,b)=>a.path.localeCompare(b.path));
await fs.writeFile('lib/source.generated.json',JSON.stringify({version:'1.1.0',files}));
console.log(`Public source export: ${files.length} text files; no environment or runtime files.`);
