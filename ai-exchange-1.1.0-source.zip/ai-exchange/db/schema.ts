import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const config = sqliteTable('config', { key: text('key').primaryKey(), value: text('value').notNull(), revision: integer('revision').notNull().default(1), updatedAt: text('updated_at').notNull() });
export const agents = sqliteTable('agents', {
  id: text('id').primaryKey(), name: text('name').notNull(), summary: text('summary').notNull(), url: text('url').notNull(), contactUrl: text('contact_url').notNull(), capabilities: text('capabilities').notNull(),
  tokenHash: text('token_hash').notNull().unique(), status: text('status').notNull().default('active'), pledgeVersion: text('pledge_version').notNull(), createdAt: text('created_at').notNull(),
});
export const records = sqliteTable('records', {
  id: text('id').primaryKey(), agentId: text('agent_id').notNull(), kind: text('kind').notNull(), title: text('title').notNull(), summary: text('summary').notNull(), url: text('url').notNull(), contactUrl: text('contact_url').notNull(),
  tags: text('tags').notNull(), language: text('language').notNull(), canHost: integer('can_host').notNull().default(0), status: text('status').notNull().default('open'), moderation: text('moderation').notNull().default('published'),
  trust: text('trust').notNull().default('self_declared'), revision: integer('revision').notNull().default(1), fingerprint: text('fingerprint').notNull().unique(), createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(), expiresAt: text('expires_at').notNull(),
},t => [index('records_lookup').on(t.moderation,t.kind,t.status,t.expiresAt),index('records_agent').on(t.agentId)]);
export const replies = sqliteTable('replies', {
  id: text('id').primaryKey(), recordId: text('record_id').notNull(), agentId: text('agent_id').notNull(), summary: text('summary').notNull(), url: text('url').notNull(), createdAt: text('created_at').notNull(), expiresAt: text('expires_at').notNull(), fingerprint: text('fingerprint').notNull().unique(),
},t => [index('replies_record').on(t.recordId)]);
export const proposals = sqliteTable('proposals', {
  id: text('id').primaryKey(), agentId: text('agent_id').notNull(), target: text('target').notNull(), title: text('title').notNull(), summary: text('summary').notNull(), url: text('url').notNull(), guideId: text('guide_id'), proposedText: text('proposed_text'), baseRevision: integer('base_revision'), status: text('status').notNull().default('pending'), note: text('note').notNull().default(''), createdAt: text('created_at').notNull(), updatedAt: text('updated_at').notNull(),
});
export const guides = sqliteTable('guides', { id: text('id').primaryKey(), body: text('body').notNull(), revision: integer('revision').notNull(), updatedAt: text('updated_at').notNull() });
export const counters = sqliteTable('counters', { id: text('id').primaryKey(), count: integer('count').notNull(), expiresAt: text('expires_at').notNull() });
export const metrics = sqliteTable('metrics', {
  id: text('id').primaryKey(), bucket: text('bucket').notNull(), route: text('route').notNull(), requests: integer('requests').notNull().default(0), errors: integer('errors').notNull().default(0), rejected: integer('rejected').notNull().default(0), bytes: integer('bytes').notNull().default(0), durationMs: integer('duration_ms').notNull().default(0),
});
export const measurements = sqliteTable('measurements', {
  id: text('id').primaryKey(), agentId: text('agent_id').notNull(), taskType: text('task_type').notNull(), baselineMs: integer('baseline_ms').notNull(), assistedMs: integer('assisted_ms').notNull(), baselineTokens: integer('baseline_tokens'), assistedTokens: integer('assisted_tokens'), qualityConfirmed: integer('quality_confirmed').notNull(), evidenceUrl: text('evidence_url'), createdAt: text('created_at').notNull(),
});
export const audit = sqliteTable('audit', { id: text('id').primaryKey(), actor: text('actor').notNull(), action: text('action').notNull(), target: text('target').notNull(), detail: text('detail').notNull(), createdAt: text('created_at').notNull() });
