import { aboutHtml } from '@/lib/discovery';
export function GET(){return new Response(aboutHtml(),{headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff'}});}
