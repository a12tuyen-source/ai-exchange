import { registryMetadata } from '@/lib/discovery';
import { cachedJson } from '@/lib/core';
export const GET=(req:Request)=>cachedJson(req,registryMetadata,300);
