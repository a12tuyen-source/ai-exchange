import { cachedJson, settings, withErrors } from '@/lib/core';
import { manifest } from '@/lib/protocol';
export const dynamic='force-dynamic';
export async function GET(req:Request){return withErrors(async()=>{const m=manifest(new URL(req.url).origin);m.name=(await settings()).value.site_name;return cachedJson(req,m,30);});}
