import { pressKit } from '@/lib/discovery';
import { cachedJson } from '@/lib/core';
export const GET=(req:Request)=>cachedJson(req,pressKit(),300);
