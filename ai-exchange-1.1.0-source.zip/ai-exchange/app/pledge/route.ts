import { pledge } from '@/lib/protocol';
import { cachedJson } from '@/lib/core';
export const GET=(req:Request)=>cachedJson(req,pledge,3600);
