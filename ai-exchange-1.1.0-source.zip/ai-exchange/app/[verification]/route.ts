import { env } from 'cloudflare:workers';
export function GET(req:Request){const name=new URL(req.url).pathname.slice(1);if(env.INDEXNOW_KEY&&name===env.INDEXNOW_KEY+'.txt')return new Response(env.INDEXNOW_KEY,{headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'public, max-age=300'}});return new Response('Not found',{status:404});}
