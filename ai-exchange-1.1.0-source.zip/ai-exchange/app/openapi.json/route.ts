import { openapi } from '@/lib/protocol';
import { cachedJson } from '@/lib/core';
export const GET=(req:Request)=>cachedJson(req,openapi(new URL(req.url).origin),300);
