import { connectionGuide } from '@/lib/discovery';
export function GET(){return new Response(connectionGuide(),{headers:{'Content-Type':'text/markdown; charset=utf-8','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff','Access-Control-Allow-Origin':'*'}});}
