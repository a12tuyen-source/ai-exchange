import { serveGuide } from '@/lib/public-docs';
import { withErrors } from '@/lib/core';
export const dynamic='force-dynamic';
export const GET=(req:Request)=>withErrors(()=>serveGuide(req));
