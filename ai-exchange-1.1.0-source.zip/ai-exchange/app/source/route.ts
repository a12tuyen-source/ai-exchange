import generated from '@/lib/source.generated.json';
const source=generated as {version:string;files:{path:string;bytes:number;sha256:string;content:string}[]};
import { cachedJson, rawJson } from '@/lib/core';
export const dynamic='force-dynamic';
export async function GET(req:Request){const path=new URL(req.url).searchParams.get('path');if(path){const f=source.files.find(x=>x.path===path);return f?cachedJson(req,f,300):rawJson({error:{code:'not_found',message:'Source path not found. Read the source index.'}},404);}return cachedJson(req,{license:'MIT for first-party app code; third-party code retains its license notices.',version:source.version,contribute:'/api/v1/proposals',automatic_deployment:false,files:source.files.map(({path,bytes,sha256})=>({path,bytes,sha256,url:`/source?path=${encodeURIComponent(path)}`}))},300);}
