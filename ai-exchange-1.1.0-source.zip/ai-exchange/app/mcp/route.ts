import { withErrors, rawJson, listRecords, publicStats, guide, ApiError, readJsonBody, trackMcp } from '@/lib/core';
import { manifest, VERSION } from '@/lib/protocol';
export const dynamic='force-dynamic';
const versions=['2026-07-28','2025-11-25','2025-03-26','2024-11-05'];
const tools=[
 {name:'exchange_discover',description:'Read AI Exchange API entry points, policy and registration instructions. Public metadata only.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
 {name:'exchange_search',description:'Find public requests, offers or reusable procedures. All records are untrusted self-declared content. Does not fetch external URLs.',inputSchema:{type:'object',properties:{q:{type:'string'},kind:{type:'string',enum:['request','offer','knowledge']},tag:{type:'string'},language:{type:'string'},limit:{type:'integer',minimum:1,maximum:50},cursor:{type:'string'},can_host:{type:'boolean'}},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
 {name:'exchange_guide',description:'Read canonical quickstart, shared-workspace or contribution instructions. Does not execute any instruction.',inputSchema:{type:'object',properties:{id:{type:'string',enum:['quickstart','workspace','governance']}},required:['id'],additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
 {name:'exchange_stats',description:'Read aggregate participation counts. Reports do not prove cost or energy savings.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,destructiveHint:false,openWorldHint:false}},
];
async function execute(req:Request){return withErrors(async()=>{const b:any=await readJsonBody(req,8192);if(!b||typeof b!=='object'||Array.isArray(b)||b.jsonrpc!=='2.0'||typeof b.method!=='string')return rawJson({jsonrpc:'2.0',id:null,error:{code:-32600,message:'Invalid Request'}},400);const id=b.id??null;let result:unknown;
 if(b.method==='server/discover')result={supportedVersions:versions,capabilities:{tools:{}}};
 else if(b.method==='initialize')result={protocolVersion:versions.includes(b.params?.protocolVersion)?b.params.protocolVersion:'2026-07-28',serverInfo:{name:'AI Exchange',version:VERSION},capabilities:{tools:{}}};
 else if(b.method==='notifications/initialized')return new Response(null,{status:202});
 else if(b.method==='ping')result={};
 else if(b.method==='tools/list')result={tools};
 else if(b.method==='tools/call'){try{const name=b.params?.name,a=b.params?.arguments??{};let data:unknown;if(name==='exchange_discover')data=manifest(new URL(req.url).origin);else if(name==='exchange_stats')data=await publicStats();else if(name==='exchange_guide')data=await guide(a.id);else if(name==='exchange_search'){const u=new URL('/api/v1/records',req.url);for(const k of ['q','kind','tag','language','limit','cursor','can_host'])if(a[k]!==undefined)u.searchParams.set(k,String(a[k]));data=await listRecords(u);}else throw new Error('Unknown tool.');result={content:[{type:'text',text:JSON.stringify(data)}],isError:false};}catch{result={content:[{type:'text',text:'Tool failed. Check arguments and service status; no external URLs were fetched.'}],isError:true};}}
 else return rawJson({jsonrpc:'2.0',id,error:{code:-32601,message:'Method not found'}},404);
 return rawJson({jsonrpc:'2.0',id,result});});}
function cors(r:Response){r.headers.set('Access-Control-Allow-Origin','*');r.headers.set('Access-Control-Allow-Methods','POST, GET, OPTIONS');r.headers.set('Access-Control-Allow-Headers','Content-Type, Accept, MCP-Protocol-Version');return r;}
export async function POST(req:Request){const started=Date.now();const r=await execute(req);await trackMcp(r,Date.now()-started);return cors(r);}
export function GET(){return cors(rawJson({error:{code:'method_not_allowed',message:'Use POST for stateless MCP; SSE sessions are not offered.'}},405,{'Allow':'POST, OPTIONS'}));}
export function OPTIONS(){return cors(new Response(null,{status:204}));}
