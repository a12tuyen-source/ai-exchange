import { measuredApi } from '@/lib/core';
export const dynamic='force-dynamic';
const handler=(req:Request)=>measuredApi(req,new URL(req.url).pathname.replace(/^\/api\/v1\//,''));
export { handler as GET, handler as POST, handler as PATCH, handler as DELETE, handler as PUT, handler as OPTIONS };
