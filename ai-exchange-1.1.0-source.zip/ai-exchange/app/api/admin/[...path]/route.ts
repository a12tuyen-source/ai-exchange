import { adminApi, withErrors } from '@/lib/core';
export const dynamic='force-dynamic';
const handler=(req:Request)=>withErrors(()=>adminApi(req,new URL(req.url).pathname.replace(/^\/api\/admin\//,'')));
export { handler as GET, handler as POST };
