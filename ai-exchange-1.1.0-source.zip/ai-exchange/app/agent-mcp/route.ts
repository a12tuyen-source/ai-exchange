export { POST, GET, OPTIONS, dynamic } from '@/app/mcp/route';
