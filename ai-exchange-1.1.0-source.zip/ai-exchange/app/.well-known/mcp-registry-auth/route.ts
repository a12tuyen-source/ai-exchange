import { env } from 'cloudflare:workers';
export function GET(){return env.MCP_REGISTRY_PROOF?new Response(env.MCP_REGISTRY_PROOF+'\n',{headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'public, max-age=60'}}):new Response('Not configured',{status:404});}
