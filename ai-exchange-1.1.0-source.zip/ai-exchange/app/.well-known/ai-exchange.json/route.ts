export { GET, dynamic } from '@/app/route';
