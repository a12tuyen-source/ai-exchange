import { requireChatGPTUser } from '@/app/chatgpt-auth';
import { requireAdmin } from '@/lib/core';
import Dashboard from './dashboard';
export const dynamic='force-dynamic';
export const metadata={title:'AI Exchange · Quản trị',robots:{index:false,follow:false}};
export default async function Admin(){await requireChatGPTUser('/admin');try{const user=await requireAdmin();return <Dashboard owner={user.displayName}/>;}catch{return <main className="access-denied"><h1>Khu vực dành cho chủ quản</h1><p>Tài khoản này chưa được cấp quyền quản trị.</p><a href="/signout-with-chatgpt?return_to=%2Fadmin" target="_top">Đổi tài khoản</a></main>;}}
