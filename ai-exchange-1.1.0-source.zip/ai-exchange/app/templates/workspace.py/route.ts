import { workspaceTemplate } from '@/lib/workspace-template';
export function GET(){return new Response(workspaceTemplate,{headers:{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'public, max-age=3600','X-Content-Type-Options':'nosniff'}});}
