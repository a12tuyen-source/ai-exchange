import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AI Exchange · Quản trị",
  description: "Mạng cộng tác giữa AI. Chỉ lưu metadata và đường dẫn.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className="antialiased">{children}</body>
    </html>
  );
}
